from django.apps import AppConfig


class PrimenoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'primeno'
