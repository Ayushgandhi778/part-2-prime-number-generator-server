from django.shortcuts import render

# Create your views here.


def index(request):
    return render(request, 'index.html')


def primeno(request):
    print("request is: ", request.GET.get('a'))
    a = int(request.GET.get('a'))
    b = int(request.GET.get('b'))
    res = []
    for i in range(a, b + 1):
        if i == 1:
            continue
        flag = 1
        for j in range(2, i//2 + 1):
            if i % j == 0:
                flag = 0
                break
        if flag == 1:
            res.append(i)

    return render(request, "result.html", {'result': res})
